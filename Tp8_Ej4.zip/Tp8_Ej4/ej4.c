#include <stdio.h>

int main(int argc, char *argv[]){

	//inicialización de arreglos donde se guardan los parámetros, las claves y los valores
	char *clave[30]; 
	char *valor[30];
	char *parametro[30];

	// incialiación de flags
	int flag_clave=0;
	int flag_valor=0;
	int flag_parametro = 0;

	//inicialización de contadores para recorrer posiciones en los arreglos creados
	int cont_claves=0; 
	int cont_param=0;
	int cont_valor = 0;
	
	
	int i;

	for(i=1; i<argc; i++){ //se recorren todas las palabras ingresada cuando se ejecuta el programa

		if(flag_valor == 1){
			flag_parametro = 0;
		}else{
			flag_parametro = 1;
		}
		
		
		if (argv[i][0] == '-'){ //la palabra corresponde a una clave
			clave[cont_claves] = &argv[i][1]; // guardar el puntero correspondiente a la segunda posicion del arreglo arrv[i] correspondiente a la clave
			printf("Opción %d: Clave: ", cont_claves+1); 
			printf("%s", clave[cont_claves]);
			cont_claves++;  
			flag_parametro = 0;
			flag_clave = 1;
		}

		if (flag_parametro ==1){
			parametro[cont_param] = argv[i]; //guardar el puntero al arreglo argv[i] correspondiente a un parámetro
			printf("Parámetro %d: ", cont_param+1);
			printf("%s\n", parametro[cont_param]);
			cont_param++;
		}

		if (flag_valor == 1){
			valor[cont_valor] = argv[i]; //guardar el puntero al arreglo argv[i] correspondiente a un valor
			printf(" Valor: ");
			printf("%s\n", valor[cont_valor]);
			cont_valor++;
			flag_valor = 0; 
		}

		if (flag_clave==1){ 
			flag_valor =1;
			flag_clave = 0;
		}

	}
}